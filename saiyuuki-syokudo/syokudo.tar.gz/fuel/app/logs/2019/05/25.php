<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

ERROR - 2019-05-25 01:37:12 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 51
ERROR - 2019-05-25 01:37:12 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 51
ERROR - 2019-05-25 01:37:25 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 51
ERROR - 2019-05-25 01:37:25 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 51
ERROR - 2019-05-25 01:37:33 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 51
ERROR - 2019-05-25 01:37:34 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 51
ERROR - 2019-05-25 02:17:37 --> Error - The requested view could not be found: welcome/404.php in /opt/lampp/htdocs/syokudo/fuel/core/classes/view.php on line 492
ERROR - 2019-05-25 02:18:18 --> Error - The requested view could not be found: welcome/404.php in /opt/lampp/htdocs/syokudo/fuel/core/classes/view.php on line 492
ERROR - 2019-05-25 02:24:45 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 51
ERROR - 2019-05-25 02:24:45 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 51
ERROR - 2019-05-25 02:24:46 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 51
ERROR - 2019-05-25 02:25:10 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 51
ERROR - 2019-05-25 02:25:10 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 51
ERROR - 2019-05-25 02:25:12 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 51
ERROR - 2019-05-25 02:25:18 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 51
ERROR - 2019-05-25 02:25:18 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 51
ERROR - 2019-05-25 02:25:34 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 51
ERROR - 2019-05-25 02:25:34 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 51
ERROR - 2019-05-25 02:25:36 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 51
ERROR - 2019-05-25 02:57:49 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 51
ERROR - 2019-05-25 02:57:49 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 51
ERROR - 2019-05-25 02:57:51 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 51
ERROR - 2019-05-25 15:42:51 --> Error - The requested view could not be found: welcome/404.php in /opt/lampp/htdocs/syokudo/fuel/core/classes/view.php on line 492
ERROR - 2019-05-25 19:48:13 --> Error - The requested view could not be found: welcome/404.php in /opt/lampp/htdocs/syokudo/fuel/core/classes/view.php on line 492
