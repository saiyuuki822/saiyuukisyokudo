<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

ERROR - 2019-05-05 04:26:57 --> Error - The requested view could not be found: welcome/404.php in /opt/lampp/htdocs/syokudo/fuel/core/classes/view.php on line 492
ERROR - 2019-05-05 12:51:27 --> Error - The requested view could not be found: welcome/404.php in /opt/lampp/htdocs/syokudo/fuel/core/classes/view.php on line 492
ERROR - 2019-05-05 16:34:56 --> Notice - A non well formed numeric value encountered in /opt/lampp/htdocs/syokudo/fuel/app/views/syokudo/menu/index.php on line 21
ERROR - 2019-05-05 16:35:55 --> Notice - A non well formed numeric value encountered in /opt/lampp/htdocs/syokudo/fuel/app/views/syokudo/menu/index.php on line 21
ERROR - 2019-05-05 16:36:27 --> Notice - A non well formed numeric value encountered in /opt/lampp/htdocs/syokudo/fuel/app/views/syokudo/menu/index.php on line 21
ERROR - 2019-05-05 16:36:46 --> Notice - A non well formed numeric value encountered in /opt/lampp/htdocs/syokudo/fuel/app/views/syokudo/menu/index.php on line 21
ERROR - 2019-05-05 16:44:25 --> Notice - A non well formed numeric value encountered in /opt/lampp/htdocs/syokudo/fuel/app/views/syokudo/menu/index.php on line 21
ERROR - 2019-05-05 16:55:45 --> Notice - A non well formed numeric value encountered in /opt/lampp/htdocs/syokudo/fuel/app/views/syokudo/menu/index.php on line 21
ERROR - 2019-05-05 16:57:37 --> Notice - A non well formed numeric value encountered in /opt/lampp/htdocs/syokudo/fuel/app/views/syokudo/menu/index.php on line 21
ERROR - 2019-05-05 16:57:50 --> Error - The requested view could not be found: welcome/404.php in /opt/lampp/htdocs/syokudo/fuel/core/classes/view.php on line 492
ERROR - 2019-05-05 16:57:51 --> Error - The requested view could not be found: welcome/404.php in /opt/lampp/htdocs/syokudo/fuel/core/classes/view.php on line 492
ERROR - 2019-05-05 16:57:52 --> Error - The requested view could not be found: welcome/404.php in /opt/lampp/htdocs/syokudo/fuel/core/classes/view.php on line 492
ERROR - 2019-05-05 22:39:31 --> Error - The requested view could not be found: welcome/404.php in /opt/lampp/htdocs/syokudo/fuel/core/classes/view.php on line 492
ERROR - 2019-05-05 22:39:32 --> Error - The requested view could not be found: welcome/404.php in /opt/lampp/htdocs/syokudo/fuel/core/classes/view.php on line 492
ERROR - 2019-05-05 22:39:34 --> Error - The requested view could not be found: welcome/404.php in /opt/lampp/htdocs/syokudo/fuel/core/classes/view.php on line 492
ERROR - 2019-05-05 22:39:35 --> Error - The requested view could not be found: welcome/404.php in /opt/lampp/htdocs/syokudo/fuel/core/classes/view.php on line 492
