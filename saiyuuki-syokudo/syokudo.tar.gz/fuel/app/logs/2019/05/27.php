<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

ERROR - 2019-05-27 19:31:59 --> Error - The requested view could not be found: welcome/404.php in /opt/lampp/htdocs/syokudo/fuel/core/classes/view.php on line 492
ERROR - 2019-05-27 21:42:49 --> Error - The requested view could not be found: welcome/404.php in /opt/lampp/htdocs/syokudo/fuel/core/classes/view.php on line 492
