<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

ERROR - 2019-04-15 06:42:30 --> Error - The requested view could not be found: welcome/404.php in /opt/lampp/htdocs/syokudo/fuel/core/classes/view.php on line 492
