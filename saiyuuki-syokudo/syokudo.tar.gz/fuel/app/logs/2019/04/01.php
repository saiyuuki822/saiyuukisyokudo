<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

ERROR - 2019-04-01 01:34:15 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 51
ERROR - 2019-04-01 01:34:15 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 51
ERROR - 2019-04-01 01:35:05 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 51
ERROR - 2019-04-01 01:35:06 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 51
ERROR - 2019-04-01 02:11:59 --> Error - The requested view could not be found: welcome/404.php in /opt/lampp/htdocs/syokudo/fuel/core/classes/view.php on line 492
ERROR - 2019-04-01 03:04:20 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 51
ERROR - 2019-04-01 03:04:20 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 51
ERROR - 2019-04-01 03:04:30 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 51
ERROR - 2019-04-01 03:04:30 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 51
ERROR - 2019-04-01 07:04:11 --> Error - The requested view could not be found: welcome/404.php in /opt/lampp/htdocs/syokudo/fuel/core/classes/view.php on line 492
ERROR - 2019-04-01 08:44:14 --> Error - The requested view could not be found: welcome/404.php in /opt/lampp/htdocs/syokudo/fuel/core/classes/view.php on line 492
ERROR - 2019-04-01 09:25:18 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 51
ERROR - 2019-04-01 09:25:18 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 51
ERROR - 2019-04-01 09:25:22 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 51
ERROR - 2019-04-01 09:28:24 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 51
ERROR - 2019-04-01 09:28:24 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 51
ERROR - 2019-04-01 09:28:26 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 51
ERROR - 2019-04-01 10:40:41 --> Error - The requested view could not be found: welcome/404.php in /opt/lampp/htdocs/syokudo/fuel/core/classes/view.php on line 492
ERROR - 2019-04-01 11:59:44 --> Error - The requested view could not be found: welcome/404.php in /opt/lampp/htdocs/syokudo/fuel/core/classes/view.php on line 492
ERROR - 2019-04-01 12:18:08 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 51
ERROR - 2019-04-01 12:18:08 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 51
ERROR - 2019-04-01 16:51:32 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 51
ERROR - 2019-04-01 16:51:32 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 51
ERROR - 2019-04-01 16:53:33 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 51
ERROR - 2019-04-01 16:53:34 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 51
ERROR - 2019-04-01 18:32:27 --> Error - The requested view could not be found: welcome/404.php in /opt/lampp/htdocs/syokudo/fuel/core/classes/view.php on line 492
ERROR - 2019-04-01 19:40:00 --> Error - The requested view could not be found: welcome/404.php in /opt/lampp/htdocs/syokudo/fuel/core/classes/view.php on line 492
