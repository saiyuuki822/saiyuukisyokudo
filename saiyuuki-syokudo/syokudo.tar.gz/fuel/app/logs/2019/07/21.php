<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

ERROR - 2019-07-21 01:04:55 --> Error - The requested view could not be found: welcome/404.php in /opt/lampp/htdocs/syokudo/fuel/core/classes/view.php on line 492
ERROR - 2019-07-21 01:04:56 --> Error - The requested view could not be found: welcome/404.php in /opt/lampp/htdocs/syokudo/fuel/core/classes/view.php on line 492
ERROR - 2019-07-21 01:04:57 --> Error - The requested view could not be found: welcome/404.php in /opt/lampp/htdocs/syokudo/fuel/core/classes/view.php on line 492
ERROR - 2019-07-21 01:04:58 --> Error - The requested view could not be found: welcome/404.php in /opt/lampp/htdocs/syokudo/fuel/core/classes/view.php on line 492
ERROR - 2019-07-21 01:04:59 --> Error - The requested view could not be found: welcome/404.php in /opt/lampp/htdocs/syokudo/fuel/core/classes/view.php on line 492
ERROR - 2019-07-21 01:05:00 --> Error - The requested view could not be found: welcome/404.php in /opt/lampp/htdocs/syokudo/fuel/core/classes/view.php on line 492
ERROR - 2019-07-21 01:05:01 --> Error - The requested view could not be found: welcome/404.php in /opt/lampp/htdocs/syokudo/fuel/core/classes/view.php on line 492
ERROR - 2019-07-21 06:39:32 --> Error - The requested view could not be found: welcome/404.php in /opt/lampp/htdocs/syokudo/fuel/core/classes/view.php on line 492
ERROR - 2019-07-21 09:51:53 --> Error - The requested view could not be found: welcome/404.php in /opt/lampp/htdocs/syokudo/fuel/core/classes/view.php on line 492
ERROR - 2019-07-21 11:50:26 --> Error - The requested view could not be found: welcome/404.php in /opt/lampp/htdocs/syokudo/fuel/core/classes/view.php on line 492
ERROR - 2019-07-21 14:26:31 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 51
ERROR - 2019-07-21 14:26:31 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 51
ERROR - 2019-07-21 14:30:32 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 51
ERROR - 2019-07-21 14:30:32 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 51
ERROR - 2019-07-21 14:30:34 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 51
ERROR - 2019-07-21 14:31:07 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 51
ERROR - 2019-07-21 14:31:08 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 51
ERROR - 2019-07-21 14:32:55 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 51
ERROR - 2019-07-21 14:32:56 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 51
ERROR - 2019-07-21 14:40:17 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 51
ERROR - 2019-07-21 14:40:17 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 51
ERROR - 2019-07-21 15:06:51 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 51
ERROR - 2019-07-21 15:06:52 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 51
ERROR - 2019-07-21 15:33:24 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 51
ERROR - 2019-07-21 15:33:24 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 51
ERROR - 2019-07-21 16:02:25 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 51
ERROR - 2019-07-21 16:02:25 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 51
ERROR - 2019-07-21 16:02:27 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 51
