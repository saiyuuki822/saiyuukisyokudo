<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

ERROR - 2019-02-06 13:44:43 --> Notice - Undefined index: menu_type in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/my.php on line 49
