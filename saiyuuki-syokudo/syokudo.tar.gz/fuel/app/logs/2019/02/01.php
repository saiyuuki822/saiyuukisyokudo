<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

ERROR - 2019-02-01 01:14:03 --> Notice - Undefined index: menu_name in /opt/lampp/htdocs/syokudo/fuel/app/views/template.php on line 30
ERROR - 2019-02-01 01:14:09 --> Notice - Undefined index: menu_name in /opt/lampp/htdocs/syokudo/fuel/app/views/template.php on line 30
