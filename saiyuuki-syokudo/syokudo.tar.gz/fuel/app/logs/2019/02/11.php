<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

ERROR - 2019-02-11 02:13:09 --> Error - syntax error, unexpected 'public' (T_PUBLIC) in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/my.php on line 69
ERROR - 2019-02-11 02:13:54 --> Error - syntax error, unexpected 'public' (T_PUBLIC) in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/my.php on line 67
ERROR - 2019-02-11 02:32:31 --> Notice - Undefined offset: 1 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/my.php on line 45
ERROR - 2019-02-11 02:36:42 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 51
ERROR - 2019-02-11 02:36:42 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 51
ERROR - 2019-02-11 02:36:54 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 51
ERROR - 2019-02-11 02:36:55 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 51
ERROR - 2019-02-11 02:43:00 --> Notice - Undefined offset: 2 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/my.php on line 45
ERROR - 2019-02-11 02:43:07 --> Notice - Undefined offset: 2 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/my.php on line 45
ERROR - 2019-02-11 07:42:09 --> Error - The requested view could not be found: template.php in /opt/lampp/htdocs/syokudo/fuel/core/classes/view.php on line 492
