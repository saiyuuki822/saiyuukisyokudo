<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

ERROR - 2019-02-04 10:18:24 --> Notice - Undefined index: menu_name in /opt/lampp/htdocs/syokudo/fuel/app/views/template.php on line 30
