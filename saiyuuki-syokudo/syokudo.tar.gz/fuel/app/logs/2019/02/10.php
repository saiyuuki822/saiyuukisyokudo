<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

ERROR - 2019-02-10 09:32:20 --> Notice - Undefined index: menu_name in /opt/lampp/htdocs/syokudo/fuel/app/views/template.php on line 30
ERROR - 2019-02-10 09:43:04 --> Notice - Undefined index: menu_name in /opt/lampp/htdocs/syokudo/fuel/app/views/template.php on line 30
ERROR - 2019-02-10 09:44:18 --> Notice - Undefined index: menu_name in /opt/lampp/htdocs/syokudo/fuel/app/views/template.php on line 30
ERROR - 2019-02-10 09:59:26 --> Notice - Undefined variable: text in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/my.php on line 44
ERROR - 2019-02-10 10:00:20 --> Notice - Undefined index: menu_name in /opt/lampp/htdocs/syokudo/fuel/app/views/template.php on line 30
ERROR - 2019-02-10 10:01:20 --> Notice - Undefined index: menu_name in /opt/lampp/htdocs/syokudo/fuel/app/views/template.php on line 30
ERROR - 2019-02-10 10:01:38 --> Notice - Undefined index: menu_name in /opt/lampp/htdocs/syokudo/fuel/app/views/template.php on line 30
ERROR - 2019-02-10 14:52:51 --> Notice - Undefined index: menu_name in /opt/lampp/htdocs/syokudo/fuel/app/views/template.php on line 30
ERROR - 2019-02-10 14:53:48 --> Notice - Undefined index: menu_name in /opt/lampp/htdocs/syokudo/fuel/app/views/template.php on line 30
ERROR - 2019-02-10 14:58:27 --> Error - syntax error, unexpected ')' in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/my.php on line 45
ERROR - 2019-02-10 15:00:02 --> Error - syntax error, unexpected ')' in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/my.php on line 45
ERROR - 2019-02-10 15:03:15 --> Notice - Undefined index: menu_name in /opt/lampp/htdocs/syokudo/fuel/app/views/template.php on line 30
ERROR - 2019-02-10 15:08:52 --> Notice - Undefined index: menu_name in /opt/lampp/htdocs/syokudo/fuel/app/views/template.php on line 30
ERROR - 2019-02-10 15:11:58 --> Notice - Undefined index: menu_name in /opt/lampp/htdocs/syokudo/fuel/app/views/template.php on line 30
ERROR - 2019-02-10 15:13:33 --> Fatal Error - Method Fuel\Core\View::__toString() must not throw an exception, caught ParseError: syntax error, unexpected ':' in /opt/lampp/htdocs/syokudo/fuel/core/classes/response.php on line 0
ERROR - 2019-02-10 15:14:02 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 52
ERROR - 2019-02-10 15:14:03 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 52
ERROR - 2019-02-10 15:14:04 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 52
ERROR - 2019-02-10 15:15:09 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 52
ERROR - 2019-02-10 15:16:36 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 52
ERROR - 2019-02-10 15:17:02 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 52
ERROR - 2019-02-10 15:17:03 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 52
ERROR - 2019-02-10 15:19:53 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 52
ERROR - 2019-02-10 15:19:53 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 52
ERROR - 2019-02-10 15:19:54 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 52
ERROR - 2019-02-10 15:20:00 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 52
ERROR - 2019-02-10 15:21:18 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 51
ERROR - 2019-02-10 15:21:19 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 51
ERROR - 2019-02-10 15:21:21 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 51
ERROR - 2019-02-10 15:21:30 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 51
ERROR - 2019-02-10 15:21:31 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 51
ERROR - 2019-02-10 15:21:58 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 51
ERROR - 2019-02-10 15:21:58 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 51
