<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

ERROR - 2019-08-22 00:55:12 --> Error - The requested view could not be found: welcome/404.php in /opt/lampp/htdocs/syokudo/fuel/core/classes/view.php on line 492
ERROR - 2019-08-22 01:45:11 --> Error - The requested view could not be found: welcome/404.php in /opt/lampp/htdocs/syokudo/fuel/core/classes/view.php on line 492
ERROR - 2019-08-22 02:19:06 --> Error - The requested view could not be found: welcome/404.php in /opt/lampp/htdocs/syokudo/fuel/core/classes/view.php on line 492
ERROR - 2019-08-22 02:36:30 --> Error - The requested view could not be found: welcome/404.php in /opt/lampp/htdocs/syokudo/fuel/core/classes/view.php on line 492
ERROR - 2019-08-22 04:02:01 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 51
ERROR - 2019-08-22 04:02:01 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 51
ERROR - 2019-08-22 07:17:46 --> Error - The requested view could not be found: welcome/404.php in /opt/lampp/htdocs/syokudo/fuel/core/classes/view.php on line 492
ERROR - 2019-08-22 08:27:54 --> Error - The requested view could not be found: welcome/404.php in /opt/lampp/htdocs/syokudo/fuel/core/classes/view.php on line 492
ERROR - 2019-08-22 09:59:10 --> Error - The requested view could not be found: welcome/404.php in /opt/lampp/htdocs/syokudo/fuel/core/classes/view.php on line 492
ERROR - 2019-08-22 09:59:11 --> Error - The requested view could not be found: welcome/404.php in /opt/lampp/htdocs/syokudo/fuel/core/classes/view.php on line 492
ERROR - 2019-08-22 09:59:13 --> Error - The requested view could not be found: welcome/404.php in /opt/lampp/htdocs/syokudo/fuel/core/classes/view.php on line 492
ERROR - 2019-08-22 09:59:14 --> Error - The requested view could not be found: welcome/404.php in /opt/lampp/htdocs/syokudo/fuel/core/classes/view.php on line 492
ERROR - 2019-08-22 09:59:15 --> Error - The requested view could not be found: welcome/404.php in /opt/lampp/htdocs/syokudo/fuel/core/classes/view.php on line 492
ERROR - 2019-08-22 10:37:24 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 51
ERROR - 2019-08-22 10:37:25 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 51
ERROR - 2019-08-22 10:37:53 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 51
ERROR - 2019-08-22 10:37:53 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 51
ERROR - 2019-08-22 10:37:55 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 51
ERROR - 2019-08-22 11:00:28 --> Error - syntax error, unexpected ')', expecting ']' in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 51
ERROR - 2019-08-22 11:18:43 --> Error - The requested view could not be found: welcome/404.php in /opt/lampp/htdocs/syokudo/fuel/core/classes/view.php on line 492
ERROR - 2019-08-22 11:20:25 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 51
ERROR - 2019-08-22 11:20:25 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 51
ERROR - 2019-08-22 11:23:42 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 52
ERROR - 2019-08-22 11:23:42 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 52
ERROR - 2019-08-22 11:24:31 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 52
ERROR - 2019-08-22 11:24:31 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 52
ERROR - 2019-08-22 11:24:32 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 52
ERROR - 2019-08-22 11:24:45 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 52
ERROR - 2019-08-22 11:24:45 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 52
ERROR - 2019-08-22 11:25:57 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 52
ERROR - 2019-08-22 11:25:57 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 52
ERROR - 2019-08-22 11:27:38 --> Fatal Error - Method Fuel\Core\View::__toString() must not throw an exception, caught ParseError: syntax error, unexpected '<', expecting end of file in /opt/lampp/htdocs/syokudo/fuel/app/views/template.php on line 0
ERROR - 2019-08-22 11:28:06 --> Fatal Error - Method Fuel\Core\View::__toString() must not throw an exception, caught ParseError: syntax error, unexpected '<', expecting end of file in /opt/lampp/htdocs/syokudo/fuel/app/views/template.php on line 0
ERROR - 2019-08-22 11:28:27 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 52
ERROR - 2019-08-22 11:28:27 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 52
ERROR - 2019-08-22 11:28:29 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 52
ERROR - 2019-08-22 11:35:55 --> Warning - Illegal offset type in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 62
ERROR - 2019-08-22 11:36:40 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 52
ERROR - 2019-08-22 11:36:41 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 52
ERROR - 2019-08-22 11:36:43 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 52
ERROR - 2019-08-22 11:37:22 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 52
ERROR - 2019-08-22 11:37:22 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 52
ERROR - 2019-08-22 11:37:24 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 52
ERROR - 2019-08-22 11:38:05 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 52
ERROR - 2019-08-22 11:38:05 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 52
ERROR - 2019-08-22 11:38:34 --> Warning - Illegal offset type in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 62
ERROR - 2019-08-22 11:39:24 --> Warning - Illegal offset type in isset or empty in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 62
ERROR - 2019-08-22 11:40:32 --> Warning - Illegal offset type in isset or empty in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 62
ERROR - 2019-08-22 11:40:50 --> Warning - Illegal offset type in isset or empty in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 62
ERROR - 2019-08-22 11:41:08 --> Warning - Illegal offset type in isset or empty in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 62
ERROR - 2019-08-22 11:41:46 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 52
ERROR - 2019-08-22 11:41:47 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 52
ERROR - 2019-08-22 11:42:54 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 52
ERROR - 2019-08-22 11:42:54 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 52
ERROR - 2019-08-22 11:43:44 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 52
ERROR - 2019-08-22 11:43:44 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 52
ERROR - 2019-08-22 11:43:46 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 52
ERROR - 2019-08-22 11:44:59 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 52
ERROR - 2019-08-22 11:44:59 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 52
ERROR - 2019-08-22 11:45:01 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 52
ERROR - 2019-08-22 11:45:40 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 52
ERROR - 2019-08-22 11:45:40 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 52
ERROR - 2019-08-22 11:48:40 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 52
ERROR - 2019-08-22 11:48:40 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 52
ERROR - 2019-08-22 11:49:03 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 52
ERROR - 2019-08-22 11:49:04 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 52
ERROR - 2019-08-22 11:49:55 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 52
ERROR - 2019-08-22 11:49:56 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 52
ERROR - 2019-08-22 11:50:33 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 52
ERROR - 2019-08-22 11:50:33 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 52
ERROR - 2019-08-22 11:51:24 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 52
ERROR - 2019-08-22 11:51:25 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 52
ERROR - 2019-08-22 11:51:27 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 52
ERROR - 2019-08-22 11:51:48 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 52
ERROR - 2019-08-22 11:51:48 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 52
ERROR - 2019-08-22 11:51:50 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 52
ERROR - 2019-08-22 11:53:26 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 52
ERROR - 2019-08-22 11:53:27 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 52
ERROR - 2019-08-22 11:53:29 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 52
ERROR - 2019-08-22 11:55:23 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 52
ERROR - 2019-08-22 11:55:24 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 52
ERROR - 2019-08-22 11:55:26 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 52
ERROR - 2019-08-22 11:55:26 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 52
ERROR - 2019-08-22 11:55:27 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 52
ERROR - 2019-08-22 11:58:50 --> Error - The requested view could not be found: welcome/404.php in /opt/lampp/htdocs/syokudo/fuel/core/classes/view.php on line 492
ERROR - 2019-08-22 14:16:20 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 52
ERROR - 2019-08-22 14:16:21 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 52
ERROR - 2019-08-22 17:45:43 --> Error - The requested view could not be found: welcome/404.php in /opt/lampp/htdocs/syokudo/fuel/core/classes/view.php on line 492
ERROR - 2019-08-22 18:01:40 --> Error - The requested view could not be found: welcome/404.php in /opt/lampp/htdocs/syokudo/fuel/core/classes/view.php on line 492
ERROR - 2019-08-22 18:35:10 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 52
ERROR - 2019-08-22 18:35:11 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 52
ERROR - 2019-08-22 18:35:14 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 52
ERROR - 2019-08-22 19:22:19 --> Error - The requested view could not be found: welcome/404.php in /opt/lampp/htdocs/syokudo/fuel/core/classes/view.php on line 492
ERROR - 2019-08-22 20:20:41 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 52
ERROR - 2019-08-22 20:20:41 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 52
ERROR - 2019-08-22 21:31:41 --> Error - The requested view could not be found: welcome/404.php in /opt/lampp/htdocs/syokudo/fuel/core/classes/view.php on line 492
ERROR - 2019-08-22 21:31:45 --> Error - The requested view could not be found: welcome/404.php in /opt/lampp/htdocs/syokudo/fuel/core/classes/view.php on line 492
ERROR - 2019-08-22 21:31:46 --> Error - The requested view could not be found: welcome/404.php in /opt/lampp/htdocs/syokudo/fuel/core/classes/view.php on line 492
ERROR - 2019-08-22 21:31:48 --> Error - The requested view could not be found: welcome/404.php in /opt/lampp/htdocs/syokudo/fuel/core/classes/view.php on line 492
ERROR - 2019-08-22 21:31:50 --> Error - The requested view could not be found: welcome/404.php in /opt/lampp/htdocs/syokudo/fuel/core/classes/view.php on line 492
ERROR - 2019-08-22 21:31:52 --> Error - The requested view could not be found: welcome/404.php in /opt/lampp/htdocs/syokudo/fuel/core/classes/view.php on line 492
ERROR - 2019-08-22 21:31:54 --> Error - The requested view could not be found: welcome/404.php in /opt/lampp/htdocs/syokudo/fuel/core/classes/view.php on line 492
ERROR - 2019-08-22 21:40:44 --> Error - The requested view could not be found: welcome/404.php in /opt/lampp/htdocs/syokudo/fuel/core/classes/view.php on line 492
ERROR - 2019-08-22 21:40:45 --> Error - The requested view could not be found: welcome/404.php in /opt/lampp/htdocs/syokudo/fuel/core/classes/view.php on line 492
ERROR - 2019-08-22 21:40:47 --> Error - The requested view could not be found: welcome/404.php in /opt/lampp/htdocs/syokudo/fuel/core/classes/view.php on line 492
ERROR - 2019-08-22 21:43:22 --> Error - The requested view could not be found: welcome/404.php in /opt/lampp/htdocs/syokudo/fuel/core/classes/view.php on line 492
ERROR - 2019-08-22 22:42:01 --> Error - The requested view could not be found: welcome/404.php in /opt/lampp/htdocs/syokudo/fuel/core/classes/view.php on line 492
ERROR - 2019-08-22 23:14:57 --> Error - The requested view could not be found: welcome/404.php in /opt/lampp/htdocs/syokudo/fuel/core/classes/view.php on line 492
