<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

ERROR - 2019-08-07 13:03:27 --> Error - The requested view could not be found: welcome/404.php in /opt/lampp/htdocs/syokudo/fuel/core/classes/view.php on line 492
ERROR - 2019-08-07 17:23:09 --> Error - The requested view could not be found: welcome/404.php in /opt/lampp/htdocs/syokudo/fuel/core/classes/view.php on line 492
ERROR - 2019-08-07 17:35:57 --> Error - The requested view could not be found: welcome/404.php in /opt/lampp/htdocs/syokudo/fuel/core/classes/view.php on line 492
ERROR - 2019-08-07 17:35:58 --> Error - The requested view could not be found: welcome/404.php in /opt/lampp/htdocs/syokudo/fuel/core/classes/view.php on line 492
ERROR - 2019-08-07 17:36:02 --> Error - The requested view could not be found: welcome/404.php in /opt/lampp/htdocs/syokudo/fuel/core/classes/view.php on line 492
ERROR - 2019-08-07 17:36:03 --> Error - The requested view could not be found: welcome/404.php in /opt/lampp/htdocs/syokudo/fuel/core/classes/view.php on line 492
ERROR - 2019-08-07 17:36:06 --> Error - The requested view could not be found: welcome/404.php in /opt/lampp/htdocs/syokudo/fuel/core/classes/view.php on line 492
ERROR - 2019-08-07 17:36:08 --> Error - The requested view could not be found: welcome/404.php in /opt/lampp/htdocs/syokudo/fuel/core/classes/view.php on line 492
ERROR - 2019-08-07 17:36:10 --> Error - The requested view could not be found: welcome/404.php in /opt/lampp/htdocs/syokudo/fuel/core/classes/view.php on line 492
ERROR - 2019-08-07 19:36:15 --> Error - The requested view could not be found: welcome/404.php in /opt/lampp/htdocs/syokudo/fuel/core/classes/view.php on line 492
ERROR - 2019-08-07 19:36:17 --> Error - The requested view could not be found: welcome/404.php in /opt/lampp/htdocs/syokudo/fuel/core/classes/view.php on line 492
ERROR - 2019-08-07 19:36:18 --> Error - The requested view could not be found: welcome/404.php in /opt/lampp/htdocs/syokudo/fuel/core/classes/view.php on line 492
