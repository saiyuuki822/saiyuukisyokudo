<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

ERROR - 2019-08-01 00:27:57 --> Error - The requested view could not be found: welcome/404.php in /opt/lampp/htdocs/syokudo/fuel/core/classes/view.php on line 492
ERROR - 2019-08-01 00:27:59 --> Error - The requested view could not be found: welcome/404.php in /opt/lampp/htdocs/syokudo/fuel/core/classes/view.php on line 492
ERROR - 2019-08-01 00:28:00 --> Error - The requested view could not be found: welcome/404.php in /opt/lampp/htdocs/syokudo/fuel/core/classes/view.php on line 492
ERROR - 2019-08-01 00:28:02 --> Error - The requested view could not be found: welcome/404.php in /opt/lampp/htdocs/syokudo/fuel/core/classes/view.php on line 492
ERROR - 2019-08-01 00:28:03 --> Error - The requested view could not be found: welcome/404.php in /opt/lampp/htdocs/syokudo/fuel/core/classes/view.php on line 492
ERROR - 2019-08-01 00:28:05 --> Error - The requested view could not be found: welcome/404.php in /opt/lampp/htdocs/syokudo/fuel/core/classes/view.php on line 492
ERROR - 2019-08-01 00:28:06 --> Error - The requested view could not be found: welcome/404.php in /opt/lampp/htdocs/syokudo/fuel/core/classes/view.php on line 492
ERROR - 2019-08-01 02:07:21 --> Error - The requested view could not be found: welcome/404.php in /opt/lampp/htdocs/syokudo/fuel/core/classes/view.php on line 492
ERROR - 2019-08-01 02:51:02 --> Error - The requested view could not be found: welcome/404.php in /opt/lampp/htdocs/syokudo/fuel/core/classes/view.php on line 492
ERROR - 2019-08-01 08:55:54 --> Error - The requested view could not be found: welcome/404.php in /opt/lampp/htdocs/syokudo/fuel/core/classes/view.php on line 492
ERROR - 2019-08-01 10:59:15 --> Error - The requested view could not be found: welcome/404.php in /opt/lampp/htdocs/syokudo/fuel/core/classes/view.php on line 492
ERROR - 2019-08-01 11:45:32 --> Error - The requested view could not be found: welcome/404.php in /opt/lampp/htdocs/syokudo/fuel/core/classes/view.php on line 492
ERROR - 2019-08-01 13:54:15 --> Error - The requested view could not be found: welcome/404.php in /opt/lampp/htdocs/syokudo/fuel/core/classes/view.php on line 492
ERROR - 2019-08-01 15:13:30 --> Error - The requested view could not be found: welcome/404.php in /opt/lampp/htdocs/syokudo/fuel/core/classes/view.php on line 492
ERROR - 2019-08-01 15:13:32 --> Error - The requested view could not be found: welcome/404.php in /opt/lampp/htdocs/syokudo/fuel/core/classes/view.php on line 492
ERROR - 2019-08-01 15:13:33 --> Error - The requested view could not be found: welcome/404.php in /opt/lampp/htdocs/syokudo/fuel/core/classes/view.php on line 492
ERROR - 2019-08-01 15:13:35 --> Error - The requested view could not be found: welcome/404.php in /opt/lampp/htdocs/syokudo/fuel/core/classes/view.php on line 492
ERROR - 2019-08-01 15:13:36 --> Error - The requested view could not be found: welcome/404.php in /opt/lampp/htdocs/syokudo/fuel/core/classes/view.php on line 492
ERROR - 2019-08-01 15:13:38 --> Error - The requested view could not be found: welcome/404.php in /opt/lampp/htdocs/syokudo/fuel/core/classes/view.php on line 492
ERROR - 2019-08-01 15:13:39 --> Error - The requested view could not be found: welcome/404.php in /opt/lampp/htdocs/syokudo/fuel/core/classes/view.php on line 492
ERROR - 2019-08-01 20:38:56 --> Error - The requested view could not be found: welcome/404.php in /opt/lampp/htdocs/syokudo/fuel/core/classes/view.php on line 492
ERROR - 2019-08-01 21:50:36 --> Error - The requested view could not be found: welcome/404.php in /opt/lampp/htdocs/syokudo/fuel/core/classes/view.php on line 492
ERROR - 2019-08-01 22:42:47 --> Error - The requested view could not be found: welcome/404.php in /opt/lampp/htdocs/syokudo/fuel/core/classes/view.php on line 492
ERROR - 2019-08-01 23:23:59 --> Error - The requested view could not be found: welcome/404.php in /opt/lampp/htdocs/syokudo/fuel/core/classes/view.php on line 492
