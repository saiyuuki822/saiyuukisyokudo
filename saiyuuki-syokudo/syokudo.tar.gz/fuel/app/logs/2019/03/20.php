<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

ERROR - 2019-03-20 13:12:43 --> Error - The requested view could not be found: template.php in /opt/lampp/htdocs/syokudo/fuel/core/classes/view.php on line 492
ERROR - 2019-03-20 13:14:48 --> Error - The requested view could not be found: template.php in /opt/lampp/htdocs/syokudo/fuel/core/classes/view.php on line 492
ERROR - 2019-03-20 13:20:57 --> Error - The requested view could not be found: template.php in /opt/lampp/htdocs/syokudo/fuel/core/classes/view.php on line 492
