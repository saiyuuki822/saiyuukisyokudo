<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

ERROR - 2019-03-10 05:34:42 --> Notice - Trying to get property 'name' of non-object in /opt/lampp/htdocs/syokudo/fuel/app/views/sub_menu.php on line 10
ERROR - 2019-03-10 05:35:13 --> Notice - Trying to get property 'link' of non-object in /opt/lampp/htdocs/syokudo/fuel/app/views/sub_menu.php on line 12
ERROR - 2019-03-10 05:44:57 --> Notice - Undefined variable: sub_menu in /opt/lampp/htdocs/syokudo/fuel/app/views/template.php on line 39
ERROR - 2019-03-10 05:45:05 --> Notice - Undefined variable: sub_menu in /opt/lampp/htdocs/syokudo/fuel/app/views/template.php on line 39
ERROR - 2019-03-10 05:45:22 --> Notice - Undefined variable: sub_menu in /opt/lampp/htdocs/syokudo/fuel/app/views/template.php on line 39
