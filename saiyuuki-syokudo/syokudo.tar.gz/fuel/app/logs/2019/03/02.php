<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

ERROR - 2019-03-02 05:40:55 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 51
ERROR - 2019-03-02 05:40:56 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 51
ERROR - 2019-03-02 05:40:57 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 51
ERROR - 2019-03-02 06:35:21 --> Notice - Undefined variable: data1 in /opt/lampp/htdocs/syokudo/fuel/app/views/contact/index.php on line 1
ERROR - 2019-03-02 06:37:25 --> Notice - Undefined variable: data1 in /opt/lampp/htdocs/syokudo/fuel/app/views/contact/index.php on line 1
ERROR - 2019-03-02 13:28:07 --> Error - Class 'Symfony\Component\HttpFoundation\Request' not found in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/contact.php on line 40
ERROR - 2019-03-02 13:30:33 --> Error - Class 'Symfony\Component\HttpFoundation\Request' not found in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/contact.php on line 40
ERROR - 2019-03-02 13:34:44 --> Error - Class 'Symfony\Component\HttpFoundation\Request' not found in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/contact.php on line 40
ERROR - 2019-03-02 13:36:55 --> Error - Class 'Symfony\Component\HttpFoundation\Request' not found in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/contact.php on line 40
ERROR - 2019-03-02 13:59:40 --> Error - Class 'Symfony\Component\HttpFoundation\Request' not found in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/contact.php on line 40
ERROR - 2019-03-02 14:08:41 --> Error - Class 'Symfony\Component\HttpFoundation\Request' not found in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/contact.php on line 40
ERROR - 2019-03-02 14:09:59 --> Error - Class 'Symfony\Component\HttpFoundation\Request' not found in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/contact.php on line 40
