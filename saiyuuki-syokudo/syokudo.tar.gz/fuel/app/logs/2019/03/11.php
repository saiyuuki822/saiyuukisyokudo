<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

ERROR - 2019-03-11 13:23:19 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 51
ERROR - 2019-03-11 13:23:20 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 51
ERROR - 2019-03-11 13:23:21 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 51
ERROR - 2019-03-11 13:24:13 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 51
ERROR - 2019-03-11 13:24:13 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 51
ERROR - 2019-03-11 13:24:15 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 51
ERROR - 2019-03-11 19:30:20 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 51
ERROR - 2019-03-11 19:30:21 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 51
ERROR - 2019-03-11 19:30:54 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 51
ERROR - 2019-03-11 19:30:55 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 51
ERROR - 2019-03-11 19:30:56 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 51
