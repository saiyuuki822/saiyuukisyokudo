<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

ERROR - 2019-01-26 03:41:19 --> Notice - Undefined index: body_value in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/my.php on line 39
ERROR - 2019-01-26 03:44:58 --> Notice - Undefined variable: data in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/my.php on line 39
ERROR - 2019-01-26 03:51:30 --> Notice - Undefined variable: list in /opt/lampp/htdocs/syokudo/fuel/app/views/template.php on line 27
ERROR - 2019-01-26 03:55:19 --> Notice - Undefined variable: list in /opt/lampp/htdocs/syokudo/fuel/app/views/template.php on line 27
ERROR - 2019-01-26 03:55:38 --> Fatal Error - Method Fuel\Core\View::__toString() must not throw an exception, caught ParseError: syntax error, unexpected '<' in /opt/lampp/htdocs/syokudo/fuel/core/classes/response.php on line 0
ERROR - 2019-01-26 03:55:53 --> Fatal Error - Method Fuel\Core\View::__toString() must not throw an exception, caught ParseError: syntax error, unexpected '<' in /opt/lampp/htdocs/syokudo/fuel/core/classes/response.php on line 0
ERROR - 2019-01-26 03:57:22 --> Fatal Error - Method Fuel\Core\View::__toString() must not throw an exception, caught ParseError: syntax error, unexpected '<' in /opt/lampp/htdocs/syokudo/fuel/core/classes/response.php on line 0
ERROR - 2019-01-26 03:57:44 --> Fatal Error - Method Fuel\Core\View::__toString() must not throw an exception, caught ParseError: syntax error, unexpected '<' in /opt/lampp/htdocs/syokudo/fuel/core/classes/response.php on line 0
ERROR - 2019-01-26 03:58:22 --> Notice - Undefined variable: data in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/my.php on line 39
ERROR - 2019-01-26 03:58:45 --> Fatal Error - Method Fuel\Core\View::__toString() must not throw an exception, caught ParseError: syntax error, unexpected '<' in /opt/lampp/htdocs/syokudo/fuel/core/classes/response.php on line 0
ERROR - 2019-01-26 03:59:24 --> Fatal Error - Method Fuel\Core\View::__toString() must not throw an exception, caught ParseError: syntax error, unexpected '<' in /opt/lampp/htdocs/syokudo/fuel/core/classes/response.php on line 0
ERROR - 2019-01-26 04:00:31 --> Fatal Error - Method Fuel\Core\View::__toString() must not throw an exception, caught ParseError: syntax error, unexpected '$data' (T_VARIABLE) in /opt/lampp/htdocs/syokudo/fuel/core/classes/response.php on line 0
ERROR - 2019-01-26 04:08:35 --> Fatal Error - Method Fuel\Core\View::__toString() must not throw an exception, caught ParseError: syntax error, unexpected '"', expecting '-' or identifier (T_STRING) or variable (T_VARIABLE) or number (T_NUM_STRING) in /opt/lampp/htdocs/syokudo/fuel/core/classes/response.php on line 0
ERROR - 2019-01-26 04:11:55 --> Fatal Error - Method Fuel\Core\View::__toString() must not throw an exception, caught ParseError: syntax error, unexpected '"', expecting '-' or identifier (T_STRING) or variable (T_VARIABLE) or number (T_NUM_STRING) in /opt/lampp/htdocs/syokudo/fuel/core/classes/response.php on line 0
ERROR - 2019-01-26 04:14:07 --> Notice - Undefined variable: list in /opt/lampp/htdocs/syokudo/fuel/app/views/template.php on line 29
ERROR - 2019-01-26 04:14:40 --> Notice - Undefined variable: list in /opt/lampp/htdocs/syokudo/fuel/app/views/template.php on line 29
ERROR - 2019-01-26 04:16:14 --> Warning - Illegal string offset 'menu_name' in /opt/lampp/htdocs/syokudo/fuel/app/views/template.php on line 30
ERROR - 2019-01-26 04:17:42 --> Warning - Illegal string offset 'menu_name' in /opt/lampp/htdocs/syokudo/fuel/app/views/template.php on line 30
ERROR - 2019-01-26 04:18:17 --> Warning - Illegal string offset 'menu_name' in /opt/lampp/htdocs/syokudo/fuel/app/views/template.php on line 30
ERROR - 2019-01-26 06:47:14 --> Notice - Undefined index: image in /opt/lampp/htdocs/syokudo/fuel/app/views/blog/index.php on line 18
ERROR - 2019-01-26 06:47:27 --> Notice - Undefined index: image in /opt/lampp/htdocs/syokudo/fuel/app/views/blog/index.php on line 18
