<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

ERROR - 2019-01-14 08:22:57 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 56
ERROR - 2019-01-14 08:22:58 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 56
ERROR - 2019-01-14 08:22:59 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 56
ERROR - 2019-01-14 08:26:03 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 56
ERROR - 2019-01-14 08:26:03 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 56
ERROR - 2019-01-14 08:26:04 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 56
ERROR - 2019-01-14 08:36:35 --> Fatal Error - Method Fuel\Core\View::__toString() must not throw an exception, caught Error: Call to undefined function strp_tags() in /opt/lampp/htdocs/syokudo/fuel/app/views/template.php on line 0
ERROR - 2019-01-14 08:43:13 --> Error - Call to undefined function strp_tags() in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 40
