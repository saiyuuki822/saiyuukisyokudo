<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

ERROR - 2019-01-31 04:47:50 --> Notice - Undefined variable: label in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/welcome.php on line 39
ERROR - 2019-01-31 04:51:22 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/my.php on line 53
ERROR - 2019-01-31 04:51:27 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/my.php on line 53
ERROR - 2019-01-31 04:59:00 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/my.php on line 53
ERROR - 2019-01-31 04:59:31 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/my.php on line 53
ERROR - 2019-01-31 12:03:25 --> Notice - Undefined variable: label in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/welcome.php on line 35
ERROR - 2019-01-31 12:08:03 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/my.php on line 53
ERROR - 2019-01-31 12:10:24 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/my.php on line 53
ERROR - 2019-01-31 12:10:57 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/my.php on line 53
ERROR - 2019-01-31 12:11:03 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/my.php on line 53
ERROR - 2019-01-31 12:11:08 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/my.php on line 53
ERROR - 2019-01-31 12:15:11 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/my.php on line 53
ERROR - 2019-01-31 12:19:56 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/my.php on line 53
ERROR - 2019-01-31 12:26:14 --> Notice - Undefined index: menu_type in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/my.php on line 49
ERROR - 2019-01-31 12:27:22 --> Notice - Undefined index: menu_type in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/my.php on line 49
