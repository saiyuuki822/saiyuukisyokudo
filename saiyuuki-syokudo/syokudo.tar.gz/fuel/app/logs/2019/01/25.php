<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

ERROR - 2019-01-25 03:01:37 --> Error - Class 'My_Controller_Base' not found in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/welcome.php on line 22
ERROR - 2019-01-25 06:32:14 --> Error - Class 'My_Controller_Base' not found in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/welcome.php on line 22
ERROR - 2019-01-25 06:32:15 --> Error - Class 'My_Controller_Base' not found in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/welcome.php on line 22
ERROR - 2019-01-25 06:32:16 --> Error - Class 'My_Controller_Base' not found in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/welcome.php on line 22
ERROR - 2019-01-25 08:04:01 --> Error - Class 'My_Controller_Base' not found in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/welcome.php on line 22
ERROR - 2019-01-25 08:09:31 --> Error - Class 'My_Controller_Base' not found in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/welcome.php on line 22
ERROR - 2019-01-25 08:10:25 --> Error - Class 'Controller_My_Base' not found in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/welcome.php on line 22
ERROR - 2019-01-25 08:10:47 --> Warning - Attempt to assign property 'title' of non-object in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/my.php on line 30
ERROR - 2019-01-25 08:39:04 --> Warning - Attempt to assign property 'title' of non-object in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/welcome.php on line 33
ERROR - 2019-01-25 08:39:56 --> Warning - Attempt to assign property 'title' of non-object in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/welcome.php on line 33
ERROR - 2019-01-25 08:42:24 --> Warning - Declaration of Controller_My::after() should be compatible with Fuel\Core\Controller_Template::after($response) in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/my.php on line 22
ERROR - 2019-01-25 08:43:49 --> Error - syntax error, unexpected ')', expecting variable (T_VARIABLE) in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/my.php on line 37
ERROR - 2019-01-25 08:44:04 --> Warning - Attempt to assign property 'title' of non-object in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/welcome.php on line 33
ERROR - 2019-01-25 08:45:59 --> Warning - Attempt to assign property 'title' of non-object in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/welcome.php on line 33
ERROR - 2019-01-25 08:51:06 --> Error - Controller_Welcome::action_index() or the controller after() method must return a Response object. in /opt/lampp/htdocs/syokudo/fuel/core/classes/request.php on line 516
