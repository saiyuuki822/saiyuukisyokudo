<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

