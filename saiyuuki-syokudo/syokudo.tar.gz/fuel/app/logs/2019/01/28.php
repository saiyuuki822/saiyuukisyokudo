<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

ERROR - 2019-01-28 01:47:09 --> Notice - Undefined index: body_value in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/my.php on line 52
ERROR - 2019-01-28 06:52:09 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/my.php on line 53
ERROR - 2019-01-28 10:14:55 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/my.php on line 53
ERROR - 2019-01-28 13:16:28 --> Error - syntax error, unexpected '{', expecting ')' in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/welcome.php on line 34
