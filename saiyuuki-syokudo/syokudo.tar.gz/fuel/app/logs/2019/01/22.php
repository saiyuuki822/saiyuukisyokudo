<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

ERROR - 2019-01-22 01:37:40 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 56
ERROR - 2019-01-22 01:37:53 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 56
ERROR - 2019-01-22 14:41:05 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 56
ERROR - 2019-01-22 14:41:05 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 56
ERROR - 2019-01-22 21:22:59 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 56
