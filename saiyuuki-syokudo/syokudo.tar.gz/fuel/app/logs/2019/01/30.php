<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

ERROR - 2019-01-30 00:47:17 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/my.php on line 53
ERROR - 2019-01-30 00:47:24 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/my.php on line 53
ERROR - 2019-01-30 00:47:52 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/my.php on line 53
