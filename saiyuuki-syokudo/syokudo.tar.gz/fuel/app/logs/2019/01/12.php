<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

ERROR - 2019-01-12 21:41:32 --> Error - Presenter "Presenter_Welcome_Detail" could not be found. in /opt/lampp/htdocs/syokudo/fuel/core/classes/presenter.php on line 92
ERROR - 2019-01-12 21:42:08 --> Error - Presenter "Presenter_Welcome_Detail" could not be found. in /opt/lampp/htdocs/syokudo/fuel/core/classes/presenter.php on line 92
