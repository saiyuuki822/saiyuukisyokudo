<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

ERROR - 2019-01-24 07:34:00 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 56
ERROR - 2019-01-24 07:34:00 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 56
