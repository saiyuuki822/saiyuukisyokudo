<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

ERROR - 2019-01-27 02:19:12 --> Notice - Undefined index: image in /opt/lampp/htdocs/syokudo/fuel/app/views/blog/index.php on line 18
ERROR - 2019-01-27 02:21:17 --> Notice - Undefined index: image in /opt/lampp/htdocs/syokudo/fuel/app/views/blog/index.php on line 18
ERROR - 2019-01-27 02:21:28 --> Notice - Undefined index: image in /opt/lampp/htdocs/syokudo/fuel/app/views/blog/index.php on line 18
ERROR - 2019-01-27 02:22:42 --> Notice - Undefined index: image in /opt/lampp/htdocs/syokudo/fuel/app/views/blog/index.php on line 18
ERROR - 2019-01-27 02:23:07 --> Notice - Undefined index: image in /opt/lampp/htdocs/syokudo/fuel/app/views/blog/index.php on line 18
ERROR - 2019-01-27 02:23:39 --> Notice - Undefined index: image in /opt/lampp/htdocs/syokudo/fuel/app/views/blog/index.php on line 18
