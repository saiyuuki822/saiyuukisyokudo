<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

ERROR - 2019-01-18 11:51:15 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 56
ERROR - 2019-01-18 11:51:15 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 56
ERROR - 2019-01-18 11:51:23 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 56
ERROR - 2019-01-18 11:51:24 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 56
