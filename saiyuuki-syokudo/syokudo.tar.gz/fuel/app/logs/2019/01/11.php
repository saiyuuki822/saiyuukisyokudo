<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

ERROR - 2019-01-11 04:44:43 --> Notice - Undefined variable: response in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/blog.php on line 37
ERROR - 2019-01-11 04:52:21 --> Fatal Error - Method Fuel\Core\View::__toString() must not throw an exception, caught ParseError: syntax error, unexpected '<' in /opt/lampp/htdocs/syokudo/fuel/app/views/template.php on line 0
ERROR - 2019-01-11 04:53:03 --> Fatal Error - Method Fuel\Core\View::__toString() must not throw an exception, caught ParseError: syntax error, unexpected '<' in /opt/lampp/htdocs/syokudo/fuel/app/views/template.php on line 0
ERROR - 2019-01-11 04:54:02 --> Fatal Error - Method Fuel\Core\View::__toString() must not throw an exception, caught ParseError: syntax error, unexpected '<' in /opt/lampp/htdocs/syokudo/fuel/app/views/template.php on line 0
ERROR - 2019-01-11 04:54:28 --> Fatal Error - Method Fuel\Core\View::__toString() must not throw an exception, caught ParseError: syntax error, unexpected '<' in /opt/lampp/htdocs/syokudo/fuel/app/views/template.php on line 0
ERROR - 2019-01-11 04:54:41 --> Notice - Undefined variable: list in /opt/lampp/htdocs/syokudo/fuel/app/views/blog/index.php on line 15
ERROR - 2019-01-11 04:57:16 --> Notice - Undefined index: body in /opt/lampp/htdocs/syokudo/fuel/app/views/blog/index.php on line 20
