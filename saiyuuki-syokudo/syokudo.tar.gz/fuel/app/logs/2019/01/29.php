<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

ERROR - 2019-01-29 00:56:10 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/my.php on line 53
ERROR - 2019-01-29 04:28:50 --> Error - Presenter "Presenter_Welcome_Index" could not be found. in /opt/lampp/htdocs/syokudo/fuel/core/classes/presenter.php on line 92
ERROR - 2019-01-29 04:29:07 --> Notice - Undefined variable: data in /opt/lampp/htdocs/syokudo/fuel/app/views/welcome/index.php on line 2
ERROR - 2019-01-29 04:29:42 --> Error - Argument 3 passed to Fuel\Core\Response::forge() must be of the type array, bool given, called in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/welcome.php on line 35 in /opt/lampp/htdocs/syokudo/fuel/core/classes/response.php on line 94
ERROR - 2019-01-29 04:31:04 --> Error - syntax error, unexpected ';', expecting ')' in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/welcome.php on line 35
ERROR - 2019-01-29 04:40:05 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/my.php on line 53
ERROR - 2019-01-29 04:40:10 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/my.php on line 53
ERROR - 2019-01-29 04:40:13 --> Notice - Undefined offset: 0 in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/my.php on line 53
ERROR - 2019-01-29 04:42:19 --> Notice - Undefined variable: data in /opt/lampp/htdocs/syokudo/fuel/app/views/welcome/index.php on line 2
ERROR - 2019-01-29 04:42:53 --> Error - Argument 3 passed to Fuel\Core\Response::forge() must be of the type array, bool given, called in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/welcome.php on line 35 in /opt/lampp/htdocs/syokudo/fuel/core/classes/response.php on line 94
ERROR - 2019-01-29 04:43:08 --> Error - syntax error, unexpected ')', expecting ';' in /opt/lampp/htdocs/syokudo/fuel/app/classes/controller/welcome.php on line 35
ERROR - 2019-01-29 04:51:35 --> Error - The data parameter only accepts objects and arrays. in /opt/lampp/htdocs/syokudo/fuel/core/classes/view.php on line 131
ERROR - 2019-01-29 07:20:18 --> Error - Presenter "Presenter_Welcome_Index" could not be found. in /opt/lampp/htdocs/syokudo/fuel/core/classes/presenter.php on line 92
ERROR - 2019-01-29 07:59:00 --> Error - Presenter "Presenter_Welcome_Index" could not be found. in /opt/lampp/htdocs/syokudo/fuel/core/classes/presenter.php on line 92
ERROR - 2019-01-29 23:27:06 --> Notice - Undefined variable: data1 in /opt/lampp/htdocs/syokudo/fuel/app/views/welcome/index.php on line 2
