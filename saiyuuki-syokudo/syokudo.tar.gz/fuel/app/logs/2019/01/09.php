<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

ERROR - 2019-01-09 04:40:52 --> Error - Presenter "Presenter_Welcome_Index" could not be found. in /opt/lampp/htdocs/syokudo/fuel/core/classes/presenter.php on line 92
