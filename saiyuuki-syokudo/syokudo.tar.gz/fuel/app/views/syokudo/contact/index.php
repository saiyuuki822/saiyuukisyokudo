

<div id="main">

<section>
<h2>お問い合わせ</h2>
<form method="post" action="/contact">
  
<table class="ta1 mb1em">
<!--<caption>テーブルのキャプションを付ける場合はこれを使います!!</caption>-->
<tr>
<th>問い合わせ区分</th>
<td><input type="radio" name="type" value="ご予約" />ご予約　<input type="radio" name="type" value="ご意見・要望" />ご意見・要望　<input type="radio" name="type" value="その他" />その他</td>
</tr>  
<tr>
<th>お名前</th>
<td><input type="text" name="name" style="width:100%;height:30px;" /></td>
</tr>
<th>ご連絡先</th>
<td><input type="text" name="contact" style="width:100%;height:30px;" /></td>
</tr>
<tr>
<th>問い合わせ内容</th>
<td><textarea name="body" rows="20" style="width:99%;"></textarea></td>
</tr>
<tr>
</table>

  


<input type="submit" value="送信" />
</form>
</div>
<!--/main-->

