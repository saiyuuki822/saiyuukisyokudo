<?php echo "<p>".$data1."</p>"; ?>

